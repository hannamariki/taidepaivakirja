import Teoslomake from "./components/Teoslomake";
import Teoslista from "./components/Teoslista";
import TeoslistaHaku from "./components/TeoslistaHaku";


/*Taidepäiväkirjaan on tarkoitus tallentaa omia töitä, niiden vaiheita ja kirjata muistiinpanoja seuratakseen omaa kehitystä, 
tai vain taltioida omia töitään kuin arkistoon. Jossain vaiheessa töitä alkaa kertyä ja varastointitila vähetä, ja uusia töitä haluaisi
maalata vanhojen päälle. Joskus tulee myös vaihe, että on valmis luopumaan töistään antamalla niitä eteenpäin tai hävittämällä. 
Netti taidepäiväkirja on arkisto verkossa, jossa työt ovat järjestyksessä vuosienkin jälkeen.*/


function App() {

  const teokset = [
    {
      id: 1,
      nimi: 'Nimetön',
      paiva: '30.10.2022',
      tekniikka: 'akvarelli, Arches 300gm/m², 100% puuvilla, puolikarkea. Mattoveitsi ',
      paletti: '',
      koko: '21cm x 30,8 cm',
      sijainti: 'Kotona, makuuhuoneen seinällä',
      arvio: 'Työ onnistui yli odotusten, ja on minua muistuttamasta siitä tunteesta millaista työtä oli tehdä.',
      muistiinpanot: 'Muista miksi maalaat!',
      versio: '1',
      viittaukset: 'Tehty Tuusulan opiston akvarelimaalaus kurssilla, ja otettu kirjasta, mutta kirjaa tai teoksen alkuperäistä tekijää en kirjannut ylös',
      avainsanat: 'Italia, kanerva, talo, puu, vuoret, akvarelli, Tuusulan opisto',
  },
    {
    id: 2, 
    nimi: 'Maa ja taivas',
    paiva: '10.05.2023',
    tekniikka: 'akvarelli paperille, Arches 300gm/m², 100% puuvilla, puolikarkea. Pyöreä näädänkarvasivellin, koko 10 ja 8. Maskineste',
    paletti: '',
    koko: '23cm x 16cm',
    sijainti: 'Kotona, arkistokansio',
    arvio: 'Työ onnistui ihan hyvin, taivaan sävyt ja pilvet jäivät liian haaleksi, olisi pitänyt käyttää enemmän väriä.',
    muistiinpanot: 'Pilvien maalausta pitää harjoitella lisää',
    versio: '1',
    viittaukset: 'Kotokunnas Art, Lumoava luonto akvareilleilla, verkkokurssi, osa 3',
    avainsanat: 'Taivas, maa, mänty, kanervat, luonto, pilvet, ilta, akvarelit, Kotokunas Art',
    },
    {
      id: 3,
      nimi: 'Kärpässieni',
      paiva: '20-21.09.2023',
      tekniikka: 'akvarelli paperille, Arches 300gm/m², 100% puuvilla, puolikarkea. Erikokoisia näädänkarvasiveltimiä. Maskineste',
      paletti: 'raw sienna (SH), brunt sienna (SH), Janes Grey (DS), ultramariini (SH), cadmiun yellow light (SH), cadmiun red (SH)',
      koko: '23cm x 16cm',
      sijainti: 'Kotona, arkistokansio',
      arvio: 'Työ onnistui hyvin, ja maalaaminen oli mukavaa. Jälkeenpäin kaipaisin lisää kontrastia taustan ja sienen välillä.',
      muistiinpanot: 'tarvitsisit jonkun pienemmän välineen maskinesteen lisäämiseen, esim pienempi sivellin tai joku teräväkärkinen pyöreäterä',
      versio: '1',
      viittaukset: 'Kotokunnas Art, Ruskaretki paletilla verkkokurssi, osa 2',
      avainsanat: 'Kärpässieni, sieni, syksy, sienestys, akvarellit, Kotokunas Art',
    },
  
    ];

  return (
    <div>
      
      <h1>Taidepäiväkirja</h1>
      
     <h3>Teoksen lisäsys</h3> 
    <Teoslomake/>

      <h3>Teos haku</h3>
      <TeoslistaHaku teokset = {teokset}/>

    <h3>Teokset</h3>
    <Teoslista taulukko={teokset}/>
      
    </div>
  );

}
export default App;
