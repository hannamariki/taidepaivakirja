import { useState } from 'react';
//import DatePicker from 'react-datepicker';
//import 'react-datepicker/dist/react-datepicker.css';

function Teoslomake() {
//const [date, setDate] = useState(new Date());
  const [teos, setTeos] = useState({
    nimi: '',
    paiva: '',
    tekniikka: '',
    paletti: '',
    koko: '',
    sijainti: '',
    arvio: '',
    muistiinpanot: '',
    versio: '',
    viittaukset: '',
    avainsanat: '',
  

  });
  const [viesti, setViesti] = useState('');

 const muutaTeos = (e) =>{ 
  setTeos(
    {...teos, [e.target.name]: e.target.value}

  
  )
  if(teos.nimi.length > 0){
  setViesti('');
  }
 }
 const lisaaTeos = () =>{
  if (teos.nimi.length === 0) {
    setViesti('Teoksen nimi on pakollinen tieto')
  }else{
    setTeos({
      nimi: '',
      paiva: '',
      tekniikka: '',
      paletti: '',
      koko: '',
      sijainti: '',
      arvio: '',
      muistiinpanot: '',
      versio: '',
      viittaukset: '',
      avainsanat: '',
    
    });
    setViesti('Lisättiin');
  }
 }
//  </form><DatePicker selected={date} onChange={(date) => setDate(date)} /><br /> päivämäärä kalenterin lisääminen
//https://refine.dev/blog/react-date-picker/#select-range-within-one-component
  return (
    <form>
      <label>Teoksen nimi
        <input type='text' name='nimi' value={teos.nimi} onChange={ (e) => muutaTeos(e)}/><br />
      </label>
      <label>Päivämäärä
      <input type='text' name='paiva' value={teos.paiva} onChange={ (e) => muutaTeos(e)}/><br />
      </label>
      <label>Tekniikka
        <input type='text' name='tekniikka'value={teos.tekniikka} onChange={ (e) => muutaTeos(e)}/><br />
      </label>
      <label>Väripaletti
        <input type='text' name='paletti'value={teos.paletti} onChange={ (e) => muutaTeos(e)}/><br />
      </label>
      <label>Työn koko
        <input type='text' name='koko'value={teos.paletti} onChange={ (e) => muutaTeos(e)}/><br />
      </label>
      <label>Työn sijainti
        <input type='text' name='sijainti'value={teos.sijainti} onChange={ (e) => muutaTeos(e)}/><br />
      </label>
      <label>Oma arvio
        <input type='text' name='arvio'value={teos.parvio} onChange={ (e) => muutaTeos(e)}/><br />
      </label>
      <label>Muistiinpanot
        <input type='text' name='muistiinpanot'value={teos.muistiinpanot} onChange={ (e) => muutaTeos(e)}/><br />
      </label>
      <label>Versio
        <input type='text' name='versio'value={teos.versio} onChange={ (e) => muutaTeos(e)}/><br />
      </label>
      <label>Viittaukset
        <input type='text' name='viittaukset'value={teos.viittaukset} onChange={ (e) => muutaTeos(e)}/><br />
      </label>
      <label>Avainsanat
        <input type='text' name='avainsanat'value={teos.avainsanat} onChange={ (e) => muutaTeos(e)}/><br />
      </label>
      <input type='button' value='Lisää' onClick={() => lisaaTeos()}/><br/>
      {viesti}
    </form>
  );
}

export default Teoslomake;
