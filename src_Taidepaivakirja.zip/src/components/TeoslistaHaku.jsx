import { useState } from 'react';

function TeoslistaHaku({teokset}) {
    const [hakusana, setHakusana] = useState('');
    const [haetaan, setHaetaan] = useState(false);

    const muuta = (e) => {
        setHakusana(e.target.value);
        setHaetaan(false);
    }

    const hae = () => {
        setHaetaan(true);
    }

    const haeTeokset = () => {
        if (haetaan) {
            let result = teokset.filter(teos => 
                teos.nimi.toLowerCase().includes(hakusana.toLowerCase()) ||
                teos.paiva.toLowerCase().includes(hakusana.toLowerCase()) ||
                teos.tekniikka.toLowerCase().includes(hakusana.toLowerCase()) ||
                teos.paletti.toLowerCase().includes(hakusana.toLowerCase()) ||
                teos.koko.toLowerCase().includes(hakusana.toLowerCase()) ||
                teos.sijainti.toLowerCase().includes(hakusana.toLowerCase()) ||
                teos.arvio.toLowerCase().includes(hakusana.toLowerCase()) ||
                teos.muistiinpanot.toLowerCase().includes(hakusana.toLowerCase()) ||
                teos.versio.toLowerCase().includes(hakusana.toLowerCase()) ||
                teos.viittaukset.toLowerCase().includes(hakusana.toLowerCase()) ||
                teos.avainsanat.toLowerCase().includes(hakusana.toLowerCase()));

            if (result.length > 0) {
                let haku = result.map(teos => {
                    console.log(teos);
                    return (
                        <p key={teos.id}>
                           
                    Teoksen nimi: {teos.nimi.toUpperCase()}<br/>
                    Päivämäärä: {teos.paiva}<br/>
                    Tekniikka: {teos.tekniikka}<br/>
                    Väripaletti: {teos.paletti}<br/>
                    Työn koko: {teos.koko}<br/>
                    Työn sijainti: {teos.sijainti}<br/>
                    Oma arvio: {teos.arvio}<br/>
                    Muistiinpanot: {teos.muistiinpanot}<br/>
                    Versio: {teos.versio}<br/>
                    Viittaukset: {teos.viittaukset}<br/>
                    Avainsanat: {teos.avainsanat}<br/>
                        </p>
                    ); 
                })

                return (haku);
            } else {
                return (<p>Kyseisellä haulla ei ole teoksia</p>);
            } 
        } 
    }

    return (
        <div>
            <form>
                <label>Hakusana
                    <input type='text' name='hakusana' value={hakusana}
                        onChange={(e) => muuta(e)} />&nbsp;
                </label>
                <input type='button' value='Hae' onClick={() => hae()} />
            </form>

            {haeTeokset()}
        </div>
    )
}

export default TeoslistaHaku;
