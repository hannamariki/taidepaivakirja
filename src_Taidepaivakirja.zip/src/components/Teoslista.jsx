

function Teoslista ({taulukko}) {
    if (!Array.isArray(taulukko) || taulukko.length === 0) {
        return (<p>Teoksia ei löytynyt</p>);
    
    }
    
        return (
            <div>
            {
            taulukko.map(teos => {
            return (
                <p key={teos.id}>
                    Teoksen nimi: {teos.nimi}<br/>
                    Päivämäärä: {teos.paiva}<br/>
                    Tekniikka: {teos.tekniikka}<br/>
                    Väripaletti: {teos.paletti}<br/>
                    Työn koko: {teos.koko}<br/>
                    Työn sijainti: {teos.sijainti}<br/>
                    Oma arvio: {teos.arvio}<br/>
                    Muistiinpanot: {teos.muistiinpanot}<br/>
                    Versio: {teos.versio}<br/>
                    Viittaukset: {teos.viittaukset}<br/>
                    Avainsanat: {teos.avainsanat}<br/>
                </p>
                    );
                })
            } 
            </div>
            );
    
    }
    
    
    export default Teoslista; 
    