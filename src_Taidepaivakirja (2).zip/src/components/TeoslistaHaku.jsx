import { useState, useEffect } from 'react';
import './Tyylit.css';

function TeoslistaHaku({ teokset, setFilteredTeokset }) {
    const [hakusana, setHakusana] = useState('');

    useEffect(() => {
        const timer = setTimeout(() => {
            if (hakusana.trim() === '') {
                setFilteredTeokset(teokset);
            } else {
                const filtered = teokset.filter(teos =>
                    teos.nimi.toLowerCase().includes(hakusana.toLowerCase()) ||
                    teos.paiva.toLowerCase().includes(hakusana.toLowerCase()) ||
                    teos.tekniikka.toLowerCase().includes(hakusana.toLowerCase()) ||
                    teos.paletti.toLowerCase().includes(hakusana.toLowerCase()) ||
                    teos.koko.toLowerCase().includes(hakusana.toLowerCase()) ||
                    teos.sijainti.toLowerCase().includes(hakusana.toLowerCase()) ||
                    teos.arvio.toLowerCase().includes(hakusana.toLowerCase()) ||
                    teos.muistiinpanot.toLowerCase().includes(hakusana.toLowerCase()) ||
                    teos.versio.toLowerCase().includes(hakusana.toLowerCase()) ||
                    teos.viittaukset.toLowerCase().includes(hakusana.toLowerCase()) ||
                    teos.avainsanat.toLowerCase().includes(hakusana.toLowerCase())
                );
                setFilteredTeokset(filtered);
            }
        }, 300); 
        return () => clearTimeout(timer);
    }, [hakusana, teokset, setFilteredTeokset]);

    const muuta = (e) => setHakusana(e.target.value);

    return (
        <div className="hakukentta-container">
            <div className="hakukentta-wrapper">
                <input
                    type="text"
                    className="hakukentta"
                    placeholder="Hae teoksia..."
                    value={hakusana}
                    onChange={muuta}
                />
            </div>
        </div>
    );
}

export default TeoslistaHaku;
