import React, { useState } from 'react';
import { ImageList, ImageListItem, ImageListItemBar, Dialog, DialogTitle, DialogContent, Typography, Button, Box } from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import IconButton from '@mui/material/IconButton';
import DeleteIcon from '@mui/icons-material/Delete';
import { Link} from 'react-router-dom';





function Teoslista ({teokset}) {
    
const [avaa, setAvaa] = useState (null);

const handleOpen = (teos) => { //popUp-ikkunan avaaminen
    setAvaa(teos);
};

const handleClose = () => { //popUp-ikkunan sulkeminen
    setAvaa(null)
};
    if (!Array.isArray(teokset) || teokset.length === 0) {
        return (<p>Teoksia ei löytynyt</p>);
    
    }
    
        return (
            //Imagelist MUI kirjastosta, joka järjestelee kuvat galleriaksi, kuvat toistaiseksi haetaan public kansiosta
            <div>
                <ImageList cols={3} gap={16}> 
                    {/*3 saraketta, 16 pix välit,
                    teokset.map läy läpi jokaisen teoksen,
                    jokaiselle teokselle luodaan ImageListItem, jonka key-prop on teoksen id,
                    pointer osoittaa että kuvaa voi klikata,
                    ImageListItemBar näyttää teoksen nimen ja päivämään*/}

                    {teokset.map((teos) => (
                        <ImageListItem key = {teos.id} onClick ={() => handleOpen(teos)}>
                        <img src={teos.kuva} alt={teos.nimi} loading="lazy" style ={{ cursor: 'pointer'}} />
                        <ImageListItemBar title ={teos.nimi}
                        subtitle={<span>{teos.paiva}</span>}
                        />
                        </ImageListItem>
                    )) }
                </ImageList>
                {/*Dialog asettaa popUp-ikkunan */}
                    {avaa &&(
                        <Dialog open= {Boolean(avaa)} onClose={handleClose} maxWidth="md" fullWidth>
                            <DialogTitle>{avaa.nimi}</DialogTitle>
                        <DialogContent dividers>
                        <img src={avaa.kuva} alt={avaa.nimi} style={{ width: '100%', maxHeight: '500px', objectFit: 'contain' }} />
                        <Typography variant="body1" gutterBottom><strong>Päivämäärä:</strong> {avaa.paiva}</Typography>
                        <Typography variant="body1" gutterBottom><strong>Tekniikka:</strong> {avaa.tekniikka}</Typography>
                        <Typography variant="body1" gutterBottom><strong>Väripaletti:</strong> {avaa.paletti}</Typography>
                        <Typography variant="body1" gutterBottom><strong>Koko:</strong> {avaa.koko}</Typography>
                        <Typography variant="body1" gutterBottom><strong>Sijainti:</strong> {avaa.sijainti}</Typography>
                        <Typography variant="body1" gutterBottom><strong>Arvio:</strong> {avaa.arvio}</Typography>
                        <Typography variant="body1" gutterBottom><strong>Muistiinpanot:</strong> {avaa.muistiinpanot}</Typography>
                        <Typography variant="body1" gutterBottom><strong>Versio:</strong> {avaa.versio}</Typography>
                        <Typography variant="body1" gutterBottom><strong>Viittaukset:</strong> {avaa.viittaukset}</Typography>
                        <Typography variant="body1" gutterBottom><strong>Avainsanat:</strong> {avaa.avainsanat}</Typography>
                        </DialogContent>
                        <Box display="flex" alignItems="center" justifyContent="center">
                        <Button onClick={handleClose} color="primary">
                            Sulje
                        </Button>
                        <IconButton color='primary' component ={Link} to = {'/muokkaa/' + avaa.id} >
                        <EditIcon/>
                        </IconButton>
                        <IconButton color='secondary'>
                        <DeleteIcon /> {/*Deleteikoni ei toimi vielä*/}
                        </IconButton>
                        </Box>
                    </Dialog>
                 )}
             </div>
            );
            }

export default Teoslista;