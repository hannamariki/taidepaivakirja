function Etusivu() {
    return (
      <div>
        <h1>Tervetuloa pitämään taidepäiväkirjaa</h1>
        <p>Tähän esittely</p>
      </div>
    );
  }
  
  export default Etusivu;