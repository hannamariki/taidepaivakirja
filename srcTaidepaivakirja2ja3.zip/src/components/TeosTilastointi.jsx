import React from 'react';
import { PieChart } from '@mui/x-charts';


//Voisiko tehdä tilastointia myös esimerkiksi tekniikasta? kuinka paljon piirroksia, veisväritöitä, akryyli/öljyväri jnd.. 


function TeosTilastointi({ teokset }) {
    // Funktio suomalaisen päivämäärän muuntamiseksi
    function paivamaara(dateString) {
        const [day, month, year] = dateString.split('.').map(Number);
        return new Date(year, month - 1, day); // month - 1, koska kuukausi on 0-indeksoitu
    }

    // Lasketaan teosten määrät vuosittain
    const yearCount = teokset.reduce((acc, teos) => {
        if (teos.paiva) {
            const date = paivamaara(teos.paiva);
            const year = date.getFullYear();
            if (!isNaN(year)) {
                acc[year] = (acc[year] || 0) + 1;
            }
        }
        return acc;
    }, {});

    // Muutetaan objekti taulukoksi Pie Chartia varten
    const data = Object.entries(yearCount).map(([year, count]) => ({
        id: year,
        value: count,
        label: `${year}: ${count}`,
    }));

    const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#FF5577'];

    return (
        <div>
            <h2>Teokset vuosittain</h2>
            <PieChart
                series={[
                    {
                        data: data,
                    },
                ]}
                colors={COLORS} 
                width={400}
                height={400}
            />
        </div>
    );
}

export default TeosTilastointi;
